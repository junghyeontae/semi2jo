function viewT(dept){
    document.getElementById("tableview").style.display ="block";
}